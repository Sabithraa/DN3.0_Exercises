package com.library.service;

import com.library.repository.BookRepository;
import com.library.model.Book;

public class BookService {
    private BookRepository bookRepository;

    // Setter method for dependency injection
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Business methods
    public void addBook(Book book) {
        bookRepository.addBook(book);
    }

    public Book findBookByIsbn(String isbn) {
        return bookRepository.findByIsbn(isbn).orElse(null);
    }

    public void deleteBookByIsbn(String isbn) {
        bookRepository.deleteByIsbn(isbn);
    }

    public void printAllBooks() {
        bookRepository.findAll().forEach(System.out::println);
    }
}
