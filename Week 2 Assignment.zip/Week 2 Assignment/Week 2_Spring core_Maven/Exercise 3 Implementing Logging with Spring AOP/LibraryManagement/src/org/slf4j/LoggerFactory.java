package org.slf4j;

import com.library.aspect.LoggingAspect;

public class LoggerFactory {

	public static Logger getLogger(Class<LoggingAspect> class1) {
		// TODO Auto-generated method stub
		return null;
	}

}
