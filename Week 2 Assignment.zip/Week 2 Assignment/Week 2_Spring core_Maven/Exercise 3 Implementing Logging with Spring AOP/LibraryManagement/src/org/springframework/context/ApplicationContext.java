package org.springframework.context;

public class ApplicationContext {

}
