package org.aspectj.lang;

public class ProceedingJoinPoint {

	public Object proceed() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getSignature() {
		// TODO Auto-generated method stub
		return null;
	}

}
