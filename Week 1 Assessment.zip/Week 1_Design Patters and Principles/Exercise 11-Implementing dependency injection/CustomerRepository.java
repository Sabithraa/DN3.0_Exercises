package exercise18;

public interface CustomerRepository {
 Customer findCustomerById(String id);
}

