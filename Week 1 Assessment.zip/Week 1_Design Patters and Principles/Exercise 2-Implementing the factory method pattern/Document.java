package exercise9;

public interface Document {
    void open();
}
