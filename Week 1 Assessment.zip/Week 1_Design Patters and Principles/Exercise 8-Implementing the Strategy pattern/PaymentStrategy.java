package exercise15;

public interface PaymentStrategy {
 void pay(double amount);
}

