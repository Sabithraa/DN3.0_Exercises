package exercise13;

public class Main {
 public static void main(String[] args) {
  
     Image image1 = new ProxyImage("image1.jpg");
     
     System.out.println("First request:");
     image1.display();

     System.out.println("\nSecond request:");
     image1.display();

     Image image2 = new ProxyImage("image2.jpg");

     System.out.println("\nThird request:");
     image2.display();
 }
}

