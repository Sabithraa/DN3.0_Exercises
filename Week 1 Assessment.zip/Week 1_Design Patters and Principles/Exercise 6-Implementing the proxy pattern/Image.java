package exercise13;

public interface Image {
 void display();
}

