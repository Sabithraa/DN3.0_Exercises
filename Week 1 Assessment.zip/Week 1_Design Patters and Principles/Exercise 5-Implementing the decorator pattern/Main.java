package exercise12;

public class Main {
 public static void main(String[] args) {
     
     Notifier emailNotifier = new EmailNotifier();
     
     Notifier smsEmailNotifier = new SMSNotifierDecorator(emailNotifier);
     
     Notifier slackEmailNotifier = new SlackNotifierDecorator(emailNotifier);

     System.out.println("Basic Email Notifier:");
     emailNotifier.send("Hello World!");

     System.out.println("\nEmail + SMS Notifier:");
     smsEmailNotifier.send("Hello World!");

     System.out.println("\nEmail + Slack Notifier:");
     slackEmailNotifier.send("Hello World!");

     Notifier combinedNotifier = new SMSNotifierDecorator(new SlackNotifierDecorator(emailNotifier));
     System.out.println("\nEmail + SMS + Slack Notifier:");
     combinedNotifier.send("Hello World!");
 }
}

