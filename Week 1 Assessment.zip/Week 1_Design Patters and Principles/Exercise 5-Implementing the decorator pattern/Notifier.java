package exercise12;

public interface Notifier {
 void send(String message);
}
