package exercise14;

public interface Observer {
 void update(double price);
}

