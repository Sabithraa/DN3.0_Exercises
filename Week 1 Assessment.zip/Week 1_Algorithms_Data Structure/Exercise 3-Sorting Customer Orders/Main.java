package exercise3;

	public class Main {
	    public static void main(String[] args) {
	   
	        Order[] orders = new Order[] {
	            new Order("O001", "Customer1", 250.0),
	            new Order("O002", "Customer2", 150.0),
	            new Order("O003", "Customer3", 450.0),
	            new Order("O004", "Customer4", 300.0),
	            new Order("O005", "Customer5", 200.0)
	        };

	        System.out.println("Orders before sorting:");
	        printOrders(orders);

	        Order[] bubbleSortedOrders = orders.clone(); 
	        BubbleSort.sort(bubbleSortedOrders);
	        System.out.println("\nOrders sorted by Bubble Sort:");
	        printOrders(bubbleSortedOrders);

	        Order[] quickSortedOrders = orders.clone(); 
	        QuickSort.sort(quickSortedOrders);
	        System.out.println("\nOrders sorted by Quick Sort:");
	        printOrders(quickSortedOrders);
	    }

	    private static void printOrders(Order[] orders) {
	        for (Order order : orders) {
	            System.out.println(order);
	        }
	    }
	}


