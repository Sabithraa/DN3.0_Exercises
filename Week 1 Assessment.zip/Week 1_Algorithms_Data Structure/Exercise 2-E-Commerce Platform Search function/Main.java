package exercise2;

	public class Main {
	    public static void main(String[] args) {
	   
	        Product[] products = new Product[] {
	            new Product("P001", "Product1", "Category1"),
	            new Product("P002", "Product2", "Category2"),
	            new Product("P003", "Product3", "Category3")
	        };

	        String searchTerm = "Product2";
	        Product resultLinear = LinearSearch.search(products, searchTerm);
	        System.out.println("Linear Search Result: " + resultLinear);

	        BinarySearch.sortById(products); 
	        Product resultBinary = BinarySearch.search(products, searchTerm);
	        System.out.println("Binary Search Result: " + resultBinary);
	    }
	}


