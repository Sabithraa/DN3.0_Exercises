package exercise2;

	import java.util.Arrays;

	public class BinarySearch {
	    public static Product search(Product[] products, String searchTerm) {
	        int left = 0;
	        int right = products.length - 1;

	        while (left <= right) {
	            int mid = left + (right - left) / 2;
	            Product midProduct = products[mid];

	            if (midProduct.getpId().equals(searchTerm) ||
	                midProduct.getpName().equals(searchTerm) ||
	                midProduct.getCategory().equals(searchTerm)) {
	                return midProduct;
	            }

	            if (searchTerm.compareTo(midProduct.getpId()) < 0) {
	                right = mid - 1;
	            } else {
	                left = mid + 1;
	            }
	        }
	        return null; 
	    }

	    public static void sortById(Product[] products) {
	        Arrays.sort(products, (p1, p2) -> p1.getpId().compareTo(p2.getpId()));
	    }
	}


