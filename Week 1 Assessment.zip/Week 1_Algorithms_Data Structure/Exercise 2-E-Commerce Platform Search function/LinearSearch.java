package exercise2;
	public class LinearSearch {
	    public static Product search(Product[] products, String searchTerm) {
	        for (Product product : products) {
	            if (product.getpId().equals(searchTerm) ||
	                product.getpName().equals(searchTerm) ||
	                product.getCategory().equals(searchTerm)) {
	                return product;
	            }
	        }
	        return null; 
	    }
	}


