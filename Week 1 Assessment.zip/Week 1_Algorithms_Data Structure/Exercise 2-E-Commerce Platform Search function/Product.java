package exercise2;

	public class Product {
	    private String pId;
	    private String pName;
	    private String category;

	    public Product(String pId, String pName, String category) {
	        this.pId = pId;
	        this.pName = pName;
	        this.category = category;
	    }

	    public String getpId() {
	        return pId;
	    }

	    public String getpName() {
	        return pName;
	    }

	    public String getCategory() {
	        return category;
	    }

	    @Override
	    public String toString() {
	        return "Product[ID=" + pId + ", Name=" + pName + ", Category=" + category + "]";
	    }
	}


