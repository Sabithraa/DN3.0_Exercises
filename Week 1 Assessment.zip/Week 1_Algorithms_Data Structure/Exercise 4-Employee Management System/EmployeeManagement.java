package exercise4;

	import java.util.Arrays;

	public class EmployeeManagement {
	    private Employee[] employees;
	    private int size; 

	    public EmployeeManagement(int capacity) {
	        employees = new Employee[capacity];
	        size = 0;
	    }

	    public void addEmployee(Employee employee) {
	        if (size >= employees.length) {
	            System.out.println("Array is full. Cannot add more employees.");
	            return;
	        }
	        employees[size++] = employee;
	    }

	    public Employee searchEmployeeById(String employeeId) {
	        for (int i = 0; i < size; i++) {
	            if (employees[i].getEmployeeId().equals(employeeId)) {
	                return employees[i];
	            }
	        }
	        return null; 
	    }

	    public void traverseEmployees() {
	        for (int i = 0; i < size; i++) {
	            System.out.println(employees[i]);
	        }
	    }

	    public void deleteEmployeeById(String employeeId) {
	        int indexToDelete = -1;
	        for (int i = 0; i < size; i++) {
	            if (employees[i].getEmployeeId().equals(employeeId)) {
	                indexToDelete = i;
	                break;
	            }
	        }
	        if (indexToDelete == -1) {
	            System.out.println("Employee not found.");
	            return;
	        }
	     
	        for (int i = indexToDelete; i < size - 1; i++) {
	            employees[i] = employees[i + 1];
	        }
	        employees[size - 1] = null; 
	        size--;
	    }
	}

