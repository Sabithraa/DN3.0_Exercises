package exercise4;
	public class Main {
	    public static void main(String[] args) {
	       
	        EmployeeManagement management = new EmployeeManagement(5);

	        Employee emp1 = new Employee("E001", "Alice Johnson", "Software Engineer", 75000);
	        Employee emp2 = new Employee("E002", "Bob Smith", "Project Manager", 85000);
	        Employee emp3 = new Employee("E003", "Charlie Brown", "UX Designer", 70000);
	        Employee emp4 = new Employee("E004", "David Wilson", "Data Analyst", 72000);
	        Employee emp5 = new Employee("E005", "Eva Adams", "HR Manager", 78000);

	        management.addEmployee(emp1);
	        management.addEmployee(emp2);
	        management.addEmployee(emp3);
	        management.addEmployee(emp4);
	        management.addEmployee(emp5);

	        System.out.println("All Employees:");
	        management.traverseEmployees();

	        System.out.println("\nSearching for Employee with ID E003:");
	        Employee foundEmployee = management.searchEmployeeById("E003");
	        if (foundEmployee != null) {
	            System.out.println("Found: " + foundEmployee);
	        } else {
	            System.out.println("Employee not found.");
	        }

	        System.out.println("\nDeleting Employee with ID E002:");
	        management.deleteEmployeeById("E002");

	        System.out.println("\nAll Employees After Deletion:");
	        management.traverseEmployees();
	    }
	}


