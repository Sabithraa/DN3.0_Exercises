package exercise5;

public class Main {
 public static void main(String[] args) {
   
     TaskManagementSystem taskSystem = new TaskManagementSystem();

     Task task1 = new Task("T001", "Design Homepage", "In Progress");
     Task task2 = new Task("T002", "Develop Backend", "Not Started");
     Task task3 = new Task("T003", "Write Documentation", "Completed");
     Task task4 = new Task("T004", "Testing and QA", "Not Started");
     Task task5 = new Task("T005", "Deploy to Production", "In Progress");

     taskSystem.addTask(task1);
     taskSystem.addTask(task2);
     taskSystem.addTask(task3);
     taskSystem.addTask(task4);
     taskSystem.addTask(task5);

     System.out.println("All Tasks:");
     taskSystem.traverseTasks();

     System.out.println("\nSearching for Task with ID T003:");
     Task foundTask = taskSystem.searchTaskById("T003");
     if (foundTask != null) {
         System.out.println("Found: " + foundTask);
     } else {
         System.out.println("Task not found.");
     }

     System.out.println("\nDeleting Task with ID T002:");
     taskSystem.deleteTaskById("T002");

     System.out.println("\nAll Tasks After Deletion:");
     taskSystem.traverseTasks();
 }
}

