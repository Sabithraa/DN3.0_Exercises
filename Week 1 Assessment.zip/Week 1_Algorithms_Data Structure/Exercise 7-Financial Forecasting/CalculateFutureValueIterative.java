package exercise7;
class CalculateFutureValueIterative{
public static double CalculateFutureValue(double currentValue, double growthRate, int periods) {
 double futureValue = currentValue;
 for (int i = 0; i < periods; i++) {
     futureValue *= (1 + growthRate);
 }
 return futureValue;
}
}
