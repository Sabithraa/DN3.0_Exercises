package exercise7;

public class Main {
    public static void main(String[] args) {
       
        double currentValue = 1000.0; 
        double growthRate = 0.05;     
        int periods = 10;             

        double futureValueRecursive = FinancialForecasting.CalculateFutureValue(currentValue, growthRate, periods);
        System.out.println("Future Value (Recursive): $" + String.format("%.2f", futureValueRecursive));

 
        double futureValueIterative = FinancialForecasting.CalculateFutureValue(currentValue, growthRate, periods);
        System.out.println("Future Value (Iterative): $" + String.format("%.2f", futureValueIterative));
    }
}
