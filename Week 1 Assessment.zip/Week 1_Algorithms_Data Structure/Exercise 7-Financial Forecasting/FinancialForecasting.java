package exercise7;

public class FinancialForecasting {

 public static double CalculateFutureValue(double currentValue, double growthRate, int periods) {
     
     if (periods == 0) {
         return currentValue;
     }
    
     return CalculateFutureValue(currentValue * (1 + growthRate), growthRate, periods - 1);
 }
}

