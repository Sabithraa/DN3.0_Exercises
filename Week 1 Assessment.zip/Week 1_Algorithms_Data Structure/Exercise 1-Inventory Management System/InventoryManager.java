package ctsPackage;


	import java.util.ArrayList;
	import java.util.List;

	public class InventoryManager {
	    private List<Product> inventory = new ArrayList<>();

	    public void add(Product product) {
	        inventory.add(product);
	    }

	    public void update(String pId, Product update) {
	        for (int i = 0; i < inventory.size(); i++) {
	            if (inventory.get(i).getpId().equals(pId)) {
	                inventory.set(i, update);
	                return;
	            }
	        }
	    }

	    public void delete(String pId) {
	        for (int i = 0; i < inventory.size(); i++) {
	            if (inventory.get(i).getpId().equals(pId)) {
	                inventory.remove(i);
	                return;
	            }
	        }
	    }

	    public Product get(String pId) {
	        for (Product product : inventory) {
	            if (product.getpId().equals(pId)) {
	                return product;
	            }
	        }
	        return null;
	    }
	}


