package ctsPackage;

	public class Main {
	    public static void main(String[] args) {
	        InventoryManager manager = new InventoryManager();

	        Product product1 = new Product("001", "Widget", 100, 19.99);
	        Product product2 = new Product("002", "Gadget", 200, 29.99);

	        manager.add(product1);
	        manager.add(product2);

	        Product retrievedProduct = manager.get("001");
	        if (retrievedProduct != null) {
	            System.out.println("Product 001: " + retrievedProduct.getpName());
	        } else {
	            System.out.println("Product 001 not found.");
	        }

	        Product updatedProduct1 = new Product("001", "Widget", 150, 17.99);
	        manager.update("001", updatedProduct1);

	        retrievedProduct = manager.get("001");
	        if (retrievedProduct != null) {
	            System.out.println("Updated Product 001: " + retrievedProduct.getpName());
	        } else {
	            System.out.println("Product 001 not found.");
	        }

	        manager.delete("002");

	        retrievedProduct = manager.get("002");
	        if (retrievedProduct != null) {
	            System.out.println("Product 002: " + retrievedProduct.getpName());
	        } else {
	            System.out.println("Product 002 not found.");
	        }
	    }
	}


