package exercise6;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Main {
 public static void main(String[] args) {
    
     List<Book> books = new ArrayList<>();
     books.add(new Book("B001", "The Great Gatsby", "F. Scott Fitzgerald"));
     books.add(new Book("B002", "To Kill a Mockingbird", "Harper Lee"));
     books.add(new Book("B003", "1984", "George Orwell"));
     books.add(new Book("B004", "Pride and Prejudice", "Jane Austen"));
     books.add(new Book("B005", "The Catcher in the Rye", "J.D. Salinger"));

     String searchTitle = "1984";
     System.out.println("Linear Search for Book with Title: " + searchTitle);
     Book foundBookLinear = LibraryManagementSystem.linearSearchByTitle(books, searchTitle);
     if (foundBookLinear != null) {
         System.out.println("Found: " + foundBookLinear);
     } else {
         System.out.println("Book not found.");
     }

     Collections.sort(books, Comparator.comparing(Book::getTitle));
     System.out.println("\nBinary Search for Book with Title: " + searchTitle);
     Book foundBookBinary = LibraryManagementSystem.binarySearchByTitle(books, searchTitle);
     if (foundBookBinary != null) {
         System.out.println("Found: " + foundBookBinary);
     } else {
         System.out.println("Book not found.");
     }

     searchTitle = "The Old Man and the Sea";
     System.out.println("\nLinear Search for Book with Title: " + searchTitle);
     Book notFoundBookLinear = LibraryManagementSystem.linearSearchByTitle(books, searchTitle);
     if (notFoundBookLinear != null) {
         System.out.println("Found: " + notFoundBookLinear);
     } else {
         System.out.println("Book not found.");
     }

     System.out.println("\nBinary Search for Book with Title: " + searchTitle);
     Book notFoundBookBinary = LibraryManagementSystem.binarySearchByTitle(books, searchTitle);
     if (notFoundBookBinary != null) {
         System.out.println("Found: " + notFoundBookBinary);
     } else {
         System.out.println("Book not found.");
     }
 }
}
