package exercise6;

import java.util.List;

public class LibraryManagementSystem {

 public static Book linearSearchByTitle(List<Book> books, String title) {
     for (Book book : books) {
         if (book.getTitle().equalsIgnoreCase(title)) {
             return book;
         }
     }
     return null; 
 }

 public static Book binarySearchByTitle(List<Book> books, String title) {
     int low = 0;
     int high = books.size() - 1;

     while (low <= high) {
         int mid = low + (high - low) / 2;
         int cmp = books.get(mid).getTitle().compareToIgnoreCase(title);

         if (cmp == 0) {
             return books.get(mid); 
         } else if (cmp < 0) {
             low = mid + 1;
         } else {
             high = mid - 1;
         }
     }
     return null; 
 }
}

